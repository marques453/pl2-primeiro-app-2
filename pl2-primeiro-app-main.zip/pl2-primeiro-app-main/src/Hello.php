<?php
namespace Application;

class Hello {
    public static function message() : string {
        return "Hello World!!!";
    }
}